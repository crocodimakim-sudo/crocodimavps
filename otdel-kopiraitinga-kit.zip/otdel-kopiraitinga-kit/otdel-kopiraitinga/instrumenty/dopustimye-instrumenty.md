# Допустимые инструменты: кому что можно

Названия даны как в Claude Code. В Claude Code список жёстко задаётся в шапке агента, в Codex он вписан в инструкцию агента как правило (у Codex нет списка разрешённых инструментов на агента). Смысл одинаковый.

| Инструмент | Исследователь | Фактчекер | Автор | Редактор | Антислоп | Выпускающий |
|---|---|---|---|---|---|---|
| Read / Glob / Grep (чтение файлов) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Write (запись файлов) | ✅ archive, import/transkripty | ✅ archive | ✅ archive | ✅ archive | ✅ archive | ✅ export, archive |
| WebSearch / WebFetch | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Perplexity MCP | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| YouTube Transcript MCP | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Firecrawl MCP | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Ahrefs MCP | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Bash | ✅ только транскрипция | ❌ | ❌ | ❌ | ✅ только python-скрипты из `instrumenty/skripty/` | ✅ только zip, mv, `clean_text.py --check` |
| Скилы | transkribaciya | — | copywriting | — | humanizer, antislop-ru, copy-editing | — |

**Почему авторам нельзя в интернет:** иначе они тащат в текст непроверенные факты в обход фактчекера. Всё фактическое приходит только через досье.

**Запрещено всем:** публиковать что-либо от имени владельца, отправлять письма, удалять файлы, менять `reference-list/`, `formaty-kanalov/`, `pravila-proekta/`.
